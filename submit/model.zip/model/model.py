import torch.nn as nn

# 改进的 PyTorch LSTM + CNN + Transformer 模型
# 改进的 PyTorch LSTM + CNN + Transformer 模型
class CNNLSTMTransformerClassifier(nn.Module):
    def __init__(self, vocab_size, embed_dim, hidden_dim, output_dim, num_layers=2, kernel_size=3, nhead=8, num_transformer_layers=4):
        super(CNNLSTMTransformerClassifier, self).__init__()
        # 嵌入层
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        # 卷积层和池化层
        self.conv1d = nn.Conv1d(in_channels=embed_dim, out_channels=128, kernel_size=kernel_size, padding=1)
        self.pool = nn.MaxPool1d(kernel_size=2)
        # Transformer 编码器
        self.transformer_encoder_layer = nn.TransformerEncoderLayer(d_model=128, nhead=nhead)
        self.transformer_encoder = nn.TransformerEncoder(self.transformer_encoder_layer, num_layers=num_transformer_layers)
        # 多层双向 LSTM
        self.lstm1 = nn.LSTM(128, hidden_dim, batch_first=True, bidirectional=True, num_layers=num_layers)
        # 第二层 Transformer 编码器
        self.transformer_encoder_layer_2 = nn.TransformerEncoderLayer(d_model=hidden_dim * 2, nhead=nhead)
        self.transformer_encoder_2 = nn.TransformerEncoder(self.transformer_encoder_layer_2, num_layers=num_transformer_layers)
        # 添加额外的 LSTM 层
        self.lstm2 = nn.LSTM(hidden_dim * 2, hidden_dim, batch_first=True, bidirectional=True)
        # 层级归一化
        self.layer_norm = nn.LayerNorm(hidden_dim * 2)
        # Dropout 层 (50% dropout)
        self.dropout = nn.Dropout(0.5)
        # 残差连接
        self.residual_fc = nn.Linear(hidden_dim * 2, hidden_dim * 2)
        # 全连接层，ReLU 激活
        self.fc1 = nn.Linear(hidden_dim * 2, hidden_dim)
        self.relu = nn.ReLU()
        # 输出层
        self.fc2 = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        # 嵌入
        embedded = self.embedding(x)  # [batch_size, seq_len, embedding_dim]
        # 卷积操作，转置维度以适配 Conv1D
        embedded = embedded.permute(0, 2, 1)  # [batch_size, embedding_dim, seq_len]
        conv_out = self.conv1d(embedded)  # [batch_size, 128, seq_len]
        pooled_out = self.pool(conv_out)  # [batch_size, 128, seq_len/2]
        pooled_out = pooled_out.permute(2, 0, 1)  # [seq_len/2, batch_size, 128] 适配 Transformer

        # 第一层 Transformer 编码器
        transformer_out = self.transformer_encoder(pooled_out)  # [seq_len/2, batch_size, 128]
        transformer_out = transformer_out.permute(1, 0, 2)  # 转换回 [batch_size, seq_len/2, 128]

        # 第一层双向 LSTM
        lstm_out, _ = self.lstm1(transformer_out)  # [batch_size, seq_len/2, hidden_dim * 2]
        lstm_out = self.layer_norm(lstm_out)  # 添加归一化

        # 第二层 Transformer 编码器
        lstm_out = lstm_out.permute(1, 0, 2)  # [seq_len/2, batch_size, hidden_dim * 2] 适配 Transformer
        transformer_out_2 = self.transformer_encoder_2(lstm_out)  # [seq_len/2, batch_size, hidden_dim * 2]
        transformer_out_2 = transformer_out_2.permute(1, 0, 2)  # [batch_size, seq_len/2, hidden_dim * 2]

        # 第二层双向 LSTM
        lstm_out, _ = self.lstm2(transformer_out_2)  # [batch_size, seq_len/2, hidden_dim * 2]

        # 残差连接
        lstm_out_residual = lstm_out + self.residual_fc(lstm_out)  # [batch_size, seq_len/2, hidden_dim * 2]

        # 使用最后一个时间步的隐藏状态，并应用 Dropout
        lstm_out = self.dropout(lstm_out_residual[:, -1, :])  # [batch_size, hidden_dim * 2]

        # 全连接层和激活函数
        fc_out = self.fc1(lstm_out)  # [batch_size, hidden_dim]
        fc_out = self.relu(fc_out)

        # 最终输出层
        out = self.fc2(fc_out)  # [batch_size, output_dim]
        return out
