import os
import sys
import pandas as pd
import torch
from bs4 import BeautifulSoup
from torch.utils.data import DataLoader, Dataset
import jieba
from tensorflow.keras.preprocessing.sequence import pad_sequences
from model import CNNLSTMTransformerClassifier
import re
import pickle
from sklearn.metrics import f1_score
from sklearn.metrics import f1_score
# 以上为依赖包引入部分, 请根据实际情况引入
# 引入的包需要安装的, 请在requirements.txt里列明, 最好请列明版本

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")

def extract_text_from_html(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        content = file.read()
        soup = BeautifulSoup(content, 'html.parser')

        # 删除脚本和样式内容
        for script_or_style in soup(['script', 'style']):
            script_or_style.decompose()

        # 提取纯文本
        text = soup.get_text(separator='\n')

        # 去除多余的空白行
        lines = (line.strip() for line in text.splitlines())
        text = '\n'.join(line for line in lines if line)

        return text

# 运用正则化过滤文本
def clean_text(text):
    text = re.sub(r'[^A-Za-z一-龥]+', ' ', text)
    return text.strip()

# 执行测试集封装
class TextDataset(Dataset):
    def __init__(self, texts, ids):
        self.ids = ids  # 保留原始 ID 数组
        self.texts = texts  # 保留原始文本序列数组，形状应为 [num_samples, max_length]

    def __len__(self):
        return len(self.ids)

    def __getitem__(self, idx):
        return torch.tensor(self.ids[idx], dtype=torch.long), torch.tensor(self.texts[idx], dtype=torch.long)
def texts_to_sequences(texts, word_index):
    sequences = []
    for text in texts:
        sequences.append([word_index.get(word, 0) for word in text.split()])
    return sequences
# 以下为逻辑函数, main函数的入参和最终的结果输出不可修改
def main(to_pred_dir, result_save_path):
    run_py = os.path.abspath(__file__)
    model_dir = os.path.dirname(run_py)

    to_pred_dir = os.path.abspath(to_pred_dir)
    testa_csv_path = os.path.join(to_pred_dir,"testa_x", "testa_x.csv")
    testa_html_dir = os.path.join(to_pred_dir, "testa_x", "html")
    testa_image_dir = os.path.join(to_pred_dir, "testa_x", "image")

    #=-=-=-=-==-=-=-=-==-=-=-=-==-=-=-=-==-=-=-=-==-=-=-=-==-=-=-=-==
    # 以下区域为预测逻辑代码, 下面的仅为示例
    # 请选手根据实际模型预测情况修改
    # 如何提取如图中目录的所有的html文件的文本内容并和test.csv中的Ttitle进行拼接形成一个新的列text？
    testa = pd.read_csv(testa_csv_path)
    # 读取html目录下的文本内容
    titles = testa['Title']

    # 处理之后的纯文本结果
    testa['text'] = titles
    testa['text'] = testa['text'].apply(clean_text)

    # 使用 jieba 进行中文分词
    testa['text'] = testa['text'].apply(lambda x: ' '.join(jieba.cut(x)))

    X_test= testa['text']

    word_dict = {}  # 手动构建词汇表
    # for text in X_test:
    #     for word in text.split():
    #         if word not in word_dict:
    #             word_dict[word] = len(word_dict) + 1
    pkl_pth = os.path.join(model_dir, 'word_dict.pkl')
    with open(pkl_pth, 'rb') as f:
        word_dict = pickle.load(f)
    X_test_seq = texts_to_sequences(X_test, word_dict)


    max_length = max([len(x) for x in X_test_seq])

    X_test_pad = pad_sequences(X_test_seq, maxlen=max_length, padding='post')


    test_dataset = TextDataset(X_test_pad,testa['id'].to_numpy())

    test_loader = DataLoader(test_dataset, batch_size=8, shuffle=False)

    # 初始化模型
    vocab_size = len(word_dict) + 1

    embed_dim = 128
    hidden_dim = 128  # 增加隐藏层大小
    output_dim = 2

    model = CNNLSTMTransformerClassifier(vocab_size, embed_dim, hidden_dim, output_dim).to(device)

    pth = os.path.join(model_dir, 'model_state.pth')
    # 加载预训练模型
    model.load_state_dict(torch.load(pth))
    model.eval()  # 设置模型为评估模式

    with torch.no_grad():
        y_pred = []
        total_id = []
        for ids, texts in test_loader:
            # print("Batch shape:", texts.shape)
            texts = texts.to(device)
            outputs = model(texts)
            _, predicted = torch.max(outputs, 1)
            y_pred.extend(predicted.tolist())
            total_id.extend(ids.tolist())

    test = pd.DataFrame({
        'id':total_id,
        'label':y_pred
    })

    #=-=-=-=-==-=-=-=-==-=-=-=-==-=-=-=-==-=-=-=-==-=-=-=-==-=-=-=-==

    # 结果输出到result_save_path
    test.to_csv(result_save_path, index=None)



if __name__ == "__main__":
    # 以下代码请勿修改, 若因此造成的提交失败由选手自负
    to_pred_dir = sys.argv[1]  # 所需预测的文件夹路径
    result_save_path = sys.argv[2]  # 预测结果保存文件路径，已指定格式为csv
    main(to_pred_dir, result_save_path)